import React from 'react';
import Game from './components/Game';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-neutral-900 flex flex-col items-center justify-center p-4">
      <header className="w-full max-w-4xl flex justify-between items-end mb-4 border-b-4 border-red-700 pb-2">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold text-red-600 drop-shadow-[2px_2px_0_rgba(255,255,255,0.8)]" style={{ fontFamily: '"Press Start 2P", cursive' }}>
            DONKEY KONG
          </h1>
          <p className="text-gray-400 text-xs mt-2 font-mono">REACT + CANVAS CLONE</p>
        </div>
        <div className="hidden md:block text-right">
          <div className="text-yellow-500 text-sm font-bold">HIGH SCORE</div>
          <div className="text-white text-xl">12500</div>
        </div>
      </header>
      
      <main className="w-full flex flex-col items-center">
        <Game />
        
        <div className="mt-8 max-w-2xl text-center text-gray-500 text-sm font-mono hidden md:block">
          <p className="mb-2">HOW TO PLAY</p>
          <div className="flex justify-center gap-8">
            <span className="bg-gray-800 px-3 py-1 rounded">⬅ ➡ MOVE</span>
            <span className="bg-gray-800 px-3 py-1 rounded">⬆ ⬇ CLIMB</span>
            <span className="bg-gray-800 px-3 py-1 rounded">SPACE TO JUMP</span>
          </div>
        </div>
      </main>

      <footer className="mt-auto py-6 text-gray-600 text-xs text-center">
        <p>Built with React, TypeScript & Tailwind CSS</p>
      </footer>
    </div>
  );
};

export default App;