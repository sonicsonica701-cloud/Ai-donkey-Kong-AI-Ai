export enum GameState {
  MENU = 'MENU',
  PLAYING = 'PLAYING',
  GAME_OVER = 'GAME_OVER',
  VICTORY = 'VICTORY'
}

export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Entity extends Rect {
  vx: number;
  vy: number;
  color: string;
}

export interface Player extends Entity {
  isGrounded: boolean;
  isClimbing: boolean;
  isDead: boolean;
  facingRight: boolean;
  frameTimer: number; // For animation
  frameIndex: number;
  hammerTimer: number;
}

export interface Barrel extends Entity {
  active: boolean;
  state: 'rolling' | 'falling';
}

export interface Hammer extends Entity {
  active: boolean;
}

export interface Particle extends Entity {
  life: number;
}

export interface LevelData {
  platforms: Rect[];
  ladders: Rect[];
  spawnPoint: { x: number; y: number };
  goalPoint: { x: number; y: number }; // Princess location
  enemyPoint: { x: number; y: number }; // DK location
  hammerPositions: { x: number; y: number }[];
}