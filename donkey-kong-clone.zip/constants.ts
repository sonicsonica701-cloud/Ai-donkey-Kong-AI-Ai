export const CANVAS_WIDTH = 800;
export const CANVAS_HEIGHT = 600;

export const GRAVITY = 0.5;
export const FRICTION = 0.8;
export const JUMP_FORCE = -10; // Negative because Y is down
export const MOVE_SPEED = 4;
export const CLIMB_SPEED = 3;
export const BARREL_SPEED = 3;

export const PLAYER_WIDTH = 30;
export const PLAYER_HEIGHT = 36;
export const BARREL_SIZE = 24;

export const LADDER_WIDTH = 30;
export const PLATFORM_HEIGHT = 20;

export const HAMMER_DURATION = 10; // seconds
export const SCORE_BARREL_DESTROY = 500;

export const COLORS = {
  BACKGROUND: '#000000',
  PLATFORM: '#B91C1C', // red-700
  LADDER: '#3B82F6', // blue-500
  PLAYER: '#EF4444', // red-500 (Mario red)
  BARREL: '#A16207', // yellow-800
  TEXT: '#FFFFFF',
  ACCENT: '#FBBF24', // amber-400
  HAMMER: '#FCD34D', // yellow-300
};