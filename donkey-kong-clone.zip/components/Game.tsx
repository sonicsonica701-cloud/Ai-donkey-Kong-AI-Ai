import React, { useRef, useEffect, useState, useCallback } from 'react';
import { GameState, Player, Barrel, LevelData, Rect, Particle, Hammer } from '../types';
import { 
  CANVAS_WIDTH, CANVAS_HEIGHT, GRAVITY, JUMP_FORCE, MOVE_SPEED, 
  CLIMB_SPEED, PLAYER_WIDTH, PLAYER_HEIGHT, BARREL_SIZE, 
  PLATFORM_HEIGHT, LADDER_WIDTH, COLORS, BARREL_SPEED,
  HAMMER_DURATION, SCORE_BARREL_DESTROY
} from '../constants';
import { Play, RotateCcw, ArrowLeft, ArrowRight, ArrowUp, ArrowDown, Hammer as HammerIcon } from 'lucide-react';

// --- Level Design ---
const INITIAL_LEVEL: LevelData = {
  platforms: [
    // Ground
    { x: 0, y: 580, width: 800, height: 20 },
    // 1st Floor (Right aligned)
    { x: 100, y: 480, width: 700, height: 20 },
    // 2nd Floor (Left aligned)
    { x: 0, y: 380, width: 700, height: 20 },
    // 3rd Floor (Right aligned)
    { x: 100, y: 280, width: 700, height: 20 },
    // 4th Floor (Left aligned)
    { x: 0, y: 180, width: 700, height: 20 },
    // Top Floor (DK & Princess)
    { x: 250, y: 90, width: 300, height: 20 },
    // Goal Platform (Princess spot)
    { x: 250, y: 50, width: 80, height: 40 }
  ],
  ladders: [
    { x: 650, y: 480, width: LADDER_WIDTH, height: 100 },
    { x: 150, y: 380, width: LADDER_WIDTH, height: 100 },
    { x: 650, y: 280, width: LADDER_WIDTH, height: 100 },
    { x: 150, y: 180, width: LADDER_WIDTH, height: 100 },
    { x: 350, y: 90, width: LADDER_WIDTH, height: 90 }, // Final ladder to top
  ],
  spawnPoint: { x: 50, y: 540 },
  goalPoint: { x: 260, y: 40 }, // Near princess
  enemyPoint: { x: 300, y: 40 }, // DK position
  hammerPositions: [
    { x: 50, y: 350 }, // On the 2nd floor, left side
    { x: 700, y: 150 }, // Top right
  ]
};

const Game: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<GameState>(GameState.MENU);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  
  // Game State Refs (for performance in loop)
  const livesRef = useRef(3); // Ref to track lives avoiding stale closures in loop
  const playerRef = useRef<Player>({
    x: 0, y: 0, width: PLAYER_WIDTH, height: PLAYER_HEIGHT, vx: 0, vy: 0, 
    color: COLORS.PLAYER, isGrounded: false, isClimbing: false, isDead: false, 
    facingRight: true, frameTimer: 0, frameIndex: 0, hammerTimer: 0
  });
  const barrelsRef = useRef<Barrel[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const hammersRef = useRef<Hammer[]>([]);
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const lastTimeRef = useRef<number>(0);
  const barrelSpawnTimerRef = useRef<number>(0);
  const requestRef = useRef<number>();

  // --- Input Handling ---
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;
      // Prevent scrolling
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const resetGame = useCallback(() => {
    playerRef.current = {
      x: INITIAL_LEVEL.spawnPoint.x,
      y: INITIAL_LEVEL.spawnPoint.y,
      width: PLAYER_WIDTH,
      height: PLAYER_HEIGHT,
      vx: 0,
      vy: 0,
      color: COLORS.PLAYER,
      isGrounded: false,
      isClimbing: false,
      isDead: false,
      facingRight: true,
      frameTimer: 0,
      frameIndex: 0,
      hammerTimer: 0
    };
    barrelsRef.current = [];
    particlesRef.current = [];
    hammersRef.current = INITIAL_LEVEL.hammerPositions.map(pos => ({
      ...pos,
      width: 24,
      height: 24,
      active: true,
      vx: 0, vy: 0,
      color: COLORS.HAMMER
    }));
    livesRef.current = 3;
    setScore(0);
    setLives(3);
    setGameState(GameState.PLAYING);
    lastTimeRef.current = performance.now();
  }, []);

  const respawnPlayer = () => {
    playerRef.current.x = INITIAL_LEVEL.spawnPoint.x;
    playerRef.current.y = INITIAL_LEVEL.spawnPoint.y;
    playerRef.current.vx = 0;
    playerRef.current.vy = 0;
    playerRef.current.isDead = false;
    playerRef.current.isClimbing = false;
    playerRef.current.hammerTimer = 0;
  };

  const spawnBarrel = () => {
    // Spawn near DK
    barrelsRef.current.push({
      x: INITIAL_LEVEL.enemyPoint.x + 50,
      y: INITIAL_LEVEL.enemyPoint.y + 50, // Slightly below DK
      width: BARREL_SIZE,
      height: BARREL_SIZE,
      vx: BARREL_SPEED,
      vy: 0,
      color: COLORS.BARREL,
      active: true,
      state: 'rolling'
    });
  };

  const checkCollision = (rect1: Rect, rect2: Rect) => {
    return (
      rect1.x < rect2.x + rect2.width &&
      rect1.x + rect1.width > rect2.x &&
      rect1.y < rect2.y + rect2.height &&
      rect1.y + rect1.height > rect2.y
    );
  };

  const spawnParticles = (x: number, y: number, color: string, count: number = 5) => {
    for (let i = 0; i < count; i++) {
      particlesRef.current.push({
        x, y, width: 4, height: 4,
        vx: (Math.random() - 0.5) * 5,
        vy: (Math.random() - 0.5) * 5,
        life: 1.0,
        color
      });
    }
  };

  const handleDeath = () => {
    if (playerRef.current.isDead) return;
    
    playerRef.current.isDead = true;
    spawnParticles(playerRef.current.x, playerRef.current.y, COLORS.PLAYER, 20);
    
    // Use livesRef to avoid stale closure in game loop
    if (livesRef.current > 1) {
      livesRef.current -= 1;
      setLives(livesRef.current);
      setTimeout(() => {
        respawnPlayer();
      }, 1500);
    } else {
      livesRef.current = 0;
      setLives(0);
      setGameState(GameState.GAME_OVER);
    }
  };

  // --- Main Game Loop ---
  const update = (timestamp: number) => {
    if (gameState !== GameState.PLAYING) return;

    const dt = (timestamp - lastTimeRef.current) / 1000;
    lastTimeRef.current = timestamp;

    const player = playerRef.current;
    
    // 0. Powerup Timer
    if (player.hammerTimer > 0) {
      player.hammerTimer -= dt;
      if (player.hammerTimer < 0) player.hammerTimer = 0;
    }

    // 1. Controls
    if (!player.isDead) {
      // Horizontal Movement
      if (keysRef.current['ArrowRight']) {
        player.vx = MOVE_SPEED;
        player.facingRight = true;
      } else if (keysRef.current['ArrowLeft']) {
        player.vx = -MOVE_SPEED;
        player.facingRight = false;
      } else {
        player.vx = 0;
      }

      // Ladder Logic
      let onLadder = false;
      for (const ladder of INITIAL_LEVEL.ladders) {
        // Broad check for ladder interaction
        if (
          player.x + player.width / 2 > ladder.x &&
          player.x + player.width / 2 < ladder.x + ladder.width &&
          player.y + player.height > ladder.y &&
          player.y < ladder.y + ladder.height
        ) {
          onLadder = true;
          // While on ladder, UP/DOWN moves vertically
          if (keysRef.current['ArrowUp']) {
            player.isClimbing = true;
            player.vy = -CLIMB_SPEED;
          } else if (keysRef.current['ArrowDown']) {
            player.isClimbing = true;
            player.vy = CLIMB_SPEED;
          } else if (player.isClimbing) {
            player.vy = 0; // Stop if no key pressed while climbing
          }
          break;
        }
      }

      if (!onLadder) {
        player.isClimbing = false;
      }

      // Jump (only if grounded and not climbing)
      if ((keysRef.current['Space'] || keysRef.current['ArrowUp']) && player.isGrounded && !player.isClimbing) {
        player.vy = JUMP_FORCE;
        player.isGrounded = false;
        // Simple jump sound effect logic (simulated)
      }

      // Gravity
      if (!player.isClimbing) {
        player.vy += GRAVITY;
      } else {
        // Snap X to center of ladder when climbing to look nice
        // (Optional polish, skipping for raw control feel)
      }
    }

    // 2. Physics & Collisions (Player)
    player.x += player.vx;
    player.y += player.vy;

    // Floor Collision
    player.isGrounded = false;
    for (const platform of INITIAL_LEVEL.platforms) {
      // Check if player is falling onto a platform
      // Previous Y calculation to check if we crossed the line
      const prevY = player.y - player.vy;
      
      if (
        player.x + player.width > platform.x &&
        player.x < platform.x + platform.width &&
        player.y + player.height >= platform.y &&
        player.y + player.height <= platform.y + platform.height + 10 && // Tolerance
        prevY + player.height <= platform.y + 5 // Was above?
      ) {
        if (!player.isClimbing) { // Don't snap to platform if climbing through it (except top)
             player.y = platform.y - player.height;
             player.vy = 0;
             player.isGrounded = true;
        }
      }
    }

    // Screen Bounds
    if (player.x < 0) player.x = 0;
    if (player.x + player.width > CANVAS_WIDTH) player.x = CANVAS_WIDTH - player.width;
    if (player.y > CANVAS_HEIGHT) {
      // Fell off map
      handleDeath();
    }

    // 2.5 Hammer Collection
    hammersRef.current.forEach(hammer => {
      if (hammer.active && checkCollision(player, hammer)) {
        hammer.active = false;
        player.hammerTimer = HAMMER_DURATION;
        // Visual effect for pickup
        spawnParticles(hammer.x, hammer.y, COLORS.HAMMER, 10);
      }
    });

    // 3. Barrel Logic
    barrelSpawnTimerRef.current += dt;
    if (barrelSpawnTimerRef.current > 3.0) { // Spawn every 3 seconds
      spawnBarrel();
      barrelSpawnTimerRef.current = 0;
    }

    barrelsRef.current.forEach(barrel => {
      barrel.vy += GRAVITY;
      barrel.x += barrel.vx;
      barrel.y += barrel.vy;

      let grounded = false;
      for (const platform of INITIAL_LEVEL.platforms) {
         if (
          barrel.x + barrel.width > platform.x &&
          barrel.x < platform.x + platform.width &&
          barrel.y + barrel.height >= platform.y &&
          barrel.y + barrel.height <= platform.y + platform.height + 10 &&
          barrel.y - barrel.vy + barrel.height <= platform.y + 10
        ) {
          barrel.y = platform.y - barrel.height;
          barrel.vy = 0;
          grounded = true;
        }
      }

      // If barrel hits edge of screen, bounce
      if (barrel.x <= 0 || barrel.x + barrel.width >= CANVAS_WIDTH) {
          barrel.vx *= -1;
      }

      // If barrel is not grounded and not falling fast, it might have walked off a ledge
      // In this simple version, barrels just patrol platforms or fall down.
      // If it falls below screen, remove it
      if (barrel.y > CANVAS_HEIGHT) {
        barrel.active = false;
        setScore(s => s + 100); // Points for surviving a barrel
      }

      // Player Collision
      if (checkCollision(player, barrel)) {
        if (player.hammerTimer > 0) {
          // DESTROY BARREL
          barrel.active = false;
          setScore(s => s + SCORE_BARREL_DESTROY);
          spawnParticles(barrel.x, barrel.y, COLORS.BARREL, 15);
          spawnParticles(barrel.x, barrel.y, '#FFF', 5);
        } else {
          handleDeath();
        }
      }
    });

    // Cleanup inactive barrels
    barrelsRef.current = barrelsRef.current.filter(b => b.active);

    // 4. Win Condition
    // Check distance to Princess
    const distToGoal = Math.hypot(player.x - INITIAL_LEVEL.goalPoint.x, player.y - INITIAL_LEVEL.goalPoint.y);
    if (distToGoal < 50) {
      setGameState(GameState.VICTORY);
    }

    // 5. Particles
    particlesRef.current.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.life -= 0.05;
    });
    particlesRef.current = particlesRef.current.filter(p => p.life > 0);
  };

  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear Screen
    ctx.fillStyle = COLORS.BACKGROUND;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Draw Ladders
    ctx.fillStyle = COLORS.LADDER;
    INITIAL_LEVEL.ladders.forEach(ladder => {
      // Draw two side rails and rungs
      const railWidth = 4;
      ctx.fillRect(ladder.x, ladder.y, railWidth, ladder.height);
      ctx.fillRect(ladder.x + ladder.width - railWidth, ladder.y, railWidth, ladder.height);
      
      // Rungs
      for (let y = ladder.y + 10; y < ladder.y + ladder.height; y += 20) {
        ctx.fillRect(ladder.x, y, ladder.width, 4);
      }
    });

    // Draw Platforms
    ctx.fillStyle = COLORS.PLATFORM;
    INITIAL_LEVEL.platforms.forEach(platform => {
      ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
      
      // Detail lines for girder look
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(platform.x, platform.y + 5);
      ctx.lineTo(platform.x + platform.width, platform.y + 5);
      ctx.moveTo(platform.x, platform.y + 15);
      ctx.lineTo(platform.x + platform.width, platform.y + 15);
      ctx.stroke();

      // Cross hatching
      ctx.beginPath();
      for(let i = 0; i < platform.width; i+= 20) {
          ctx.moveTo(platform.x + i, platform.y);
          ctx.lineTo(platform.x + i + 10, platform.y + platform.height);
      }
      ctx.stroke();
    });

    // Draw Hammers on floor
    hammersRef.current.forEach(h => {
      if (h.active) {
        ctx.font = '24px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';
        ctx.fillText('🔨', h.x + h.width/2, h.y + h.height + 4);
      }
    });

    // Draw Player
    if (!playerRef.current.isDead) {
      const p = playerRef.current;
      // Using Emoji for simple sprite
      ctx.font = '30px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      
      ctx.save();
      ctx.translate(p.x + p.width/2, p.y + p.height);
      
      // Hammer Swing Animation effect
      if (p.hammerTimer > 0) {
        // Shake/rotate slightly
        const shake = Math.sin(Date.now() / 50) * 0.2;
        ctx.rotate(shake);
        // Add glow
        ctx.shadowColor = 'yellow';
        ctx.shadowBlur = 10;
      }

      if (!p.facingRight) ctx.scale(-1, 1);
      
      let sprite = p.isClimbing ? '🧗' : '👷'; // Climber or Construction worker
      if (p.hammerTimer > 0) sprite = '👷🔨'; // Add hammer to sprite

      ctx.fillText(sprite, 0, 5);
      ctx.restore();
      
      // Timer Bar for hammer
      if (p.hammerTimer > 0) {
        const barWidth = 40;
        const pct = p.hammerTimer / HAMMER_DURATION;
        ctx.fillStyle = 'white';
        ctx.fillRect(p.x - 5, p.y - 10, barWidth, 6);
        ctx.fillStyle = COLORS.HAMMER;
        ctx.fillRect(p.x - 4, p.y - 9, (barWidth - 2) * pct, 4);
      }
    }

    // Draw Barrels
    barrelsRef.current.forEach(b => {
      ctx.font = '24px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      ctx.fillText('🛢️', b.x + b.width/2, b.y + b.height + 2);
    });

    // Draw DK
    ctx.font = '60px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('🦍', INITIAL_LEVEL.enemyPoint.x, INITIAL_LEVEL.enemyPoint.y + 40);

    // Draw Princess
    ctx.font = '40px Arial';
    ctx.fillText('👸', INITIAL_LEVEL.goalPoint.x, INITIAL_LEVEL.goalPoint.y + 40);

    // Draw Particles
    particlesRef.current.forEach(p => {
      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.life;
      ctx.fillRect(p.x, p.y, p.width, p.height);
      ctx.globalAlpha = 1.0;
    });
  };

  const loop = (timestamp: number) => {
    update(timestamp);
    draw();
    requestRef.current = requestAnimationFrame(loop);
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(loop);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameState]);

  // Mobile Controls handlers
  const handleTouchStart = (key: string) => {
    keysRef.current[key] = true;
  };
  const handleTouchEnd = (key: string) => {
    keysRef.current[key] = false;
  };

  return (
    <div className="relative w-full max-w-[800px] aspect-[4/3] bg-gray-900 rounded-lg overflow-hidden shadow-2xl border-4 border-gray-700 mx-auto my-8">
      <canvas
        ref={canvasRef}
        width={CANVAS_WIDTH}
        height={CANVAS_HEIGHT}
        className="w-full h-full object-contain block bg-black"
      />

      {/* UI Overlay */}
      <div className="absolute top-4 left-4 text-white font-mono text-xl z-10 flex gap-8">
        <div>SCORE: {score}</div>
        <div className="text-red-500">LIVES: {'❤'.repeat(Math.max(0, lives))}</div>
      </div>
      
      {/* Powerup indicator */}
      {playerRef.current.hammerTimer > 0 && gameState === GameState.PLAYING && (
        <div className="absolute top-4 right-4 text-yellow-300 font-bold animate-pulse flex items-center gap-2 border-2 border-yellow-500 px-3 py-1 rounded bg-black/50">
           <HammerIcon size={20} /> SMASH MODE
        </div>
      )}

      {gameState === GameState.MENU && (
        <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center text-white z-20">
          <h1 className="text-6xl font-bold mb-8 text-red-500 tracking-widest text-center">
            DONKEY<br/>KONG
          </h1>
          <p className="mb-8 text-yellow-400 blink">PRESS START TO PLAY</p>
          <button 
            onClick={resetGame}
            className="flex items-center gap-2 px-8 py-4 bg-blue-600 hover:bg-blue-500 rounded text-xl font-bold transition-colors"
          >
            <Play size={24} /> START GAME
          </button>
          <div className="mt-8 text-gray-400 text-sm">
            ARROWS to Move • SPACE to Jump
          </div>
        </div>
      )}

      {gameState === GameState.GAME_OVER && (
        <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center text-white z-20">
          <h1 className="text-6xl font-bold mb-4 text-red-600">GAME OVER</h1>
          <p className="text-2xl mb-8">FINAL SCORE: {score}</p>
          <button 
            onClick={resetGame}
            className="flex items-center gap-2 px-6 py-3 bg-white text-black hover:bg-gray-200 rounded text-lg font-bold"
          >
            <RotateCcw size={20} /> TRY AGAIN
          </button>
        </div>
      )}

      {gameState === GameState.VICTORY && (
        <div className="absolute inset-0 bg-blue-900/90 flex flex-col items-center justify-center text-white z-20">
          <h1 className="text-5xl font-bold mb-4 text-yellow-300">YOU SAVED HER!</h1>
          <p className="text-2xl mb-8">SCORE: {score + 5000}</p>
          <button 
            onClick={resetGame}
            className="flex items-center gap-2 px-6 py-3 bg-yellow-400 text-black hover:bg-yellow-300 rounded text-lg font-bold"
          >
            <Play size={20} /> PLAY AGAIN
          </button>
        </div>
      )}

      {/* Mobile Controls Overlay */}
      {gameState === GameState.PLAYING && (
        <div className="absolute bottom-4 left-0 right-0 px-4 md:hidden flex justify-between items-end z-10 opacity-70">
          <div className="flex gap-2">
            <button 
              className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm active:bg-white/40"
              onTouchStart={() => handleTouchStart('ArrowLeft')}
              onTouchEnd={() => handleTouchEnd('ArrowLeft')}
            >
              <ArrowLeft className="text-white" size={32} />
            </button>
            <button 
              className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm active:bg-white/40"
              onTouchStart={() => handleTouchStart('ArrowRight')}
              onTouchEnd={() => handleTouchEnd('ArrowRight')}
            >
              <ArrowRight className="text-white" size={32} />
            </button>
          </div>
          
          <div className="flex gap-2 items-end">
             <div className="flex flex-col gap-2">
                 <button 
                  className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm active:bg-white/40"
                  onTouchStart={() => handleTouchStart('ArrowUp')}
                  onTouchEnd={() => handleTouchEnd('ArrowUp')}
                >
                  <ArrowUp className="text-white" size={32} />
                </button>
                <button 
                  className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm active:bg-white/40"
                  onTouchStart={() => handleTouchStart('ArrowDown')}
                  onTouchEnd={() => handleTouchEnd('ArrowDown')}
                >
                  <ArrowDown className="text-white" size={32} />
                </button>
             </div>
            <button 
              className="w-20 h-20 bg-red-500/40 rounded-full flex items-center justify-center backdrop-blur-sm active:bg-red-500/60 mb-8"
              onTouchStart={() => handleTouchStart('Space')}
              onTouchEnd={() => handleTouchEnd('Space')}
            >
              <div className="text-white font-bold">JUMP</div>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Game;